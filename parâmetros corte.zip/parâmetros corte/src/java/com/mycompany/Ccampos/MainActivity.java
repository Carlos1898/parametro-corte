/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  com.google.android.gms.ads.AdRequest
 *  com.google.android.gms.ads.AdRequest$Builder
 *  com.google.android.gms.ads.AdView
 *  com.google.android.gms.ads.MobileAds
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.NoClassDefFoundError
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package com.mycompany.Ccampos;

import adrt.ADRTLogCatReader;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

public class MainActivity
extends Activity {
    Button f;
    Button fr;
    private AdView mAdView;
    Button s;
    Button t;
    Button tc;

    @Override
    public void onCreate(Bundle bundle) {
        ADRTLogCatReader.onContext((Context)this, "com.aide.ui");
        super.onCreate(bundle);
        this.setContentView(2130903076);
        MobileAds.initialize((Context)this, (String)"ca-app-pub-3940256099942544/6300978111");
        this.mAdView = (AdView)this.findViewById(2131427410);
        this.t = (Button)this.findViewById(2131427427);
        this.f = (Button)this.findViewById(2131427419);
        this.fr = (Button)this.findViewById(2131427428);
        this.s = (Button)this.findViewById(2131427416);
        this.tc = (Button)this.findViewById(2131427429);
        AdRequest.Builder builder = new AdRequest.Builder();
        AdRequest adRequest = builder.build();
        this.mAdView.loadAd(adRequest);
        Button button = this.s;
        100000000 var5_5 = new 100000000(this);
        button.setOnClickListener((View.OnClickListener)var5_5);
        Button button2 = this.f;
        100000001 var7_7 = new 100000001(this);
        button2.setOnClickListener((View.OnClickListener)var7_7);
        Button button3 = this.fr;
        100000002 var9_9 = new 100000002(this);
        button3.setOnClickListener((View.OnClickListener)var9_9);
        Button button4 = this.t;
        100000003 var11_11 = new 100000003(this);
        button4.setOnClickListener((View.OnClickListener)var11_11);
        Button button5 = this.tc;
        100000004 var13_13 = new 100000004(this);
        button5.setOnClickListener((View.OnClickListener)var13_13);
    }

    @Override
    public void onDestroy() {
        if (this.mAdView != null) {
            this.mAdView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onPause() {
        if (this.mAdView != null) {
            this.mAdView.pause();
        }
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (this.mAdView != null) {
            this.mAdView.resume();
        }
    }

    class 100000000
    implements View.OnClickListener {
        private final MainActivity this$0;

        100000000(MainActivity mainActivity) {
            this.this$0 = mainActivity;
        }

        static MainActivity access$0(100000000 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            this.this$0.finish();
        }
    }

    class 100000001
    implements View.OnClickListener {
        private final MainActivity this$0;

        100000001(MainActivity mainActivity) {
            this.this$0 = mainActivity;
        }

        static MainActivity access$0(100000001 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            Class class_;
            MainActivity mainActivity = this.this$0;
            try {
                class_ = Class.forName((String)"com.mycompany.Ccampos.furacao");
            }
            catch (ClassNotFoundException classNotFoundException) {
                NoClassDefFoundError noClassDefFoundError = new NoClassDefFoundError(classNotFoundException.getMessage());
                throw noClassDefFoundError;
            }
            Intent intent = new Intent((Context)mainActivity, class_);
            this.this$0.startActivity(intent);
            this.this$0.finish();
        }
    }

    class 100000002
    implements View.OnClickListener {
        private final MainActivity this$0;

        100000002(MainActivity mainActivity) {
            this.this$0 = mainActivity;
        }

        static MainActivity access$0(100000002 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            Class class_;
            MainActivity mainActivity = this.this$0;
            try {
                class_ = Class.forName((String)"com.mycompany.Ccampos.frezamento");
            }
            catch (ClassNotFoundException classNotFoundException) {
                NoClassDefFoundError noClassDefFoundError = new NoClassDefFoundError(classNotFoundException.getMessage());
                throw noClassDefFoundError;
            }
            Intent intent = new Intent((Context)mainActivity, class_);
            this.this$0.startActivity(intent);
            this.this$0.finish();
        }
    }

    class 100000003
    implements View.OnClickListener {
        private final MainActivity this$0;

        100000003(MainActivity mainActivity) {
            this.this$0 = mainActivity;
        }

        static MainActivity access$0(100000003 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            Class class_;
            MainActivity mainActivity = this.this$0;
            try {
                class_ = Class.forName((String)"com.mycompany.Ccampos.torneamento");
            }
            catch (ClassNotFoundException classNotFoundException) {
                NoClassDefFoundError noClassDefFoundError = new NoClassDefFoundError(classNotFoundException.getMessage());
                throw noClassDefFoundError;
            }
            Intent intent = new Intent((Context)mainActivity, class_);
            this.this$0.startActivity(intent);
            this.this$0.finish();
        }
    }

    class 100000004
    implements View.OnClickListener {
        private final MainActivity this$0;

        100000004(MainActivity mainActivity) {
            this.this$0 = mainActivity;
        }

        static MainActivity access$0(100000004 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            Class class_;
            MainActivity mainActivity = this.this$0;
            try {
                class_ = Class.forName((String)"com.mycompany.Ccampos.tc");
            }
            catch (ClassNotFoundException classNotFoundException) {
                NoClassDefFoundError noClassDefFoundError = new NoClassDefFoundError(classNotFoundException.getMessage());
                throw noClassDefFoundError;
            }
            Intent intent = new Intent((Context)mainActivity, class_);
            this.this$0.startActivity(intent);
            this.this$0.finish();
        }
    }

}

