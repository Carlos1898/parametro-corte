/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.os.Bundle
 *  android.text.Editable
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.TextView
 *  com.google.android.gms.ads.AdRequest
 *  com.google.android.gms.ads.AdRequest$Builder
 *  com.google.android.gms.ads.AdView
 *  com.google.android.gms.ads.MobileAds
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Double
 *  java.lang.NoClassDefFoundError
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.text.DecimalFormat
 */
package com.mycompany.Ccampos;

import adrt.ADRTLogCatReader;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import java.text.DecimalFormat;

public class faf
extends Activity {
    Button ap;
    EditText edn;
    EditText edvf;
    EditText edz;
    Button fz;
    private AdView mAdView;
    Button s;
    TextView total;
    Button v;

    @Override
    public void onCreate(Bundle bundle) {
        ADRTLogCatReader.onContext((Context)this, "com.aide.ui");
        super.onCreate(bundle);
        this.setContentView(2130903067);
        MobileAds.initialize((Context)this, (String)"ca-app-pub-3940256099942544/6300978111");
        this.mAdView = (AdView)this.findViewById(2131427410);
        this.s = (Button)this.findViewById(2131427416);
        this.ap = (Button)this.findViewById(2131427414);
        this.v = (Button)this.findViewById(2131427417);
        this.fz = (Button)this.findViewById(2131427421);
        this.edn = (EditText)this.findViewById(2131427411);
        this.edn.setHint((CharSequence)"0");
        this.edvf = (EditText)this.findViewById(2131427418);
        this.edvf.setHint((CharSequence)"0");
        this.edz = (EditText)this.findViewById(2131427420);
        this.edz.setHint((CharSequence)"0");
        this.total = (TextView)this.findViewById(2131427413);
        AdRequest.Builder builder = new AdRequest.Builder();
        AdRequest adRequest = builder.build();
        this.mAdView.loadAd(adRequest);
        Button button = this.s;
        100000000 var5_5 = new 100000000(this);
        button.setOnClickListener((View.OnClickListener)var5_5);
        Button button2 = this.ap;
        100000001 var7_7 = new 100000001(this);
        button2.setOnClickListener((View.OnClickListener)var7_7);
        Button button3 = this.v;
        100000002 var9_9 = new 100000002(this);
        button3.setOnClickListener((View.OnClickListener)var9_9);
        Button button4 = this.fz;
        100000003 var11_11 = new 100000003(this);
        button4.setOnClickListener((View.OnClickListener)var11_11);
    }

    @Override
    public void onDestroy() {
        if (this.mAdView != null) {
            this.mAdView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onPause() {
        if (this.mAdView != null) {
            this.mAdView.pause();
        }
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (this.mAdView != null) {
            this.mAdView.resume();
        }
    }

    class 100000000
    implements View.OnClickListener {
        private final faf this$0;

        100000000(faf faf2) {
            this.this$0 = faf2;
        }

        static faf access$0(100000000 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            this.this$0.finish();
        }
    }

    class 100000001
    implements View.OnClickListener {
        private final faf this$0;

        100000001(faf faf2) {
            this.this$0 = faf2;
        }

        static faf access$0(100000001 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            this.this$0.edn.setText((CharSequence)String.valueOf((Object)""));
            this.this$0.edvf.setText((CharSequence)String.valueOf((Object)""));
            this.this$0.edz.setText((CharSequence)String.valueOf((Object)""));
            this.this$0.total.setText((CharSequence)String.valueOf((Object)""));
        }
    }

    class 100000002
    implements View.OnClickListener {
        private final faf this$0;

        100000002(faf faf2) {
            this.this$0 = faf2;
        }

        static faf access$0(100000002 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            Class class_;
            faf faf2 = this.this$0;
            try {
                class_ = Class.forName((String)"com.mycompany.Ccampos.furacao");
            }
            catch (ClassNotFoundException classNotFoundException) {
                NoClassDefFoundError noClassDefFoundError = new NoClassDefFoundError(classNotFoundException.getMessage());
                throw noClassDefFoundError;
            }
            Intent intent = new Intent((Context)faf2, class_);
            this.this$0.startActivity(intent);
            this.this$0.finish();
        }
    }

    class 100000003
    implements View.OnClickListener {
        private final faf this$0;

        100000003(faf faf2) {
            this.this$0 = faf2;
        }

        static faf access$0(100000003 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            if (this.this$0.edn.length() == 0) {
                AlertDialog.Builder builder = new AlertDialog.Builder((Context)this.this$0);
                builder.setTitle((CharSequence)"Aten\u00e7\u00e3o");
                builder.setMessage((CharSequence)"Obrigatorio digitar valor");
                builder.setNeutralButton((CharSequence)"OK", (DialogInterface.OnClickListener)null);
                builder.show();
                return;
            }
            if (this.this$0.edvf.length() == 0) {
                AlertDialog.Builder builder = new AlertDialog.Builder((Context)this.this$0);
                builder.setTitle((CharSequence)"Aten\u00e7\u00e3o");
                builder.setMessage((CharSequence)"Obrigatorio digitar valor '");
                builder.setNeutralButton((CharSequence)"OK", (DialogInterface.OnClickListener)null);
                builder.show();
                return;
            }
            if (this.this$0.edz.length() == 0) {
                AlertDialog.Builder builder = new AlertDialog.Builder((Context)this.this$0);
                builder.setTitle((CharSequence)"Aten\u00e7\u00e3o");
                builder.setMessage((CharSequence)"Obrigatorio digitar valor '");
                builder.setNeutralButton((CharSequence)"OK", (DialogInterface.OnClickListener)null);
                builder.show();
                return;
            }
            double d = Double.parseDouble((String)this.this$0.edvf.getText().toString()) / (Double.parseDouble((String)this.this$0.edn.getText().toString()) * Double.parseDouble((String)this.this$0.edz.getText().toString()));
            DecimalFormat decimalFormat = new DecimalFormat("0.000");
            this.this$0.total.setText((CharSequence)decimalFormat.format(d));
        }
    }

}

