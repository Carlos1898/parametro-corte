/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  com.google.android.gms.ads.AdRequest
 *  com.google.android.gms.ads.AdRequest$Builder
 *  com.google.android.gms.ads.AdView
 *  com.google.android.gms.ads.MobileAds
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.NoClassDefFoundError
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package com.mycompany.Ccampos;

import adrt.ADRTLogCatReader;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

public class furacao
extends Activity {
    Button f;
    Button fz;
    private AdView mAdView;
    Button n;
    Button s;
    Button v;
    Button vc;
    Button vf;

    @Override
    public void onCreate(Bundle bundle) {
        ADRTLogCatReader.onContext((Context)this, "com.aide.ui");
        super.onCreate(bundle);
        this.setContentView(2130903074);
        MobileAds.initialize((Context)this, (String)"ca-app-pub-3940256099942544/6300978111");
        this.mAdView = (AdView)this.findViewById(2131427410);
        this.s = (Button)this.findViewById(2131427416);
        this.v = (Button)this.findViewById(2131427417);
        this.vc = (Button)this.findViewById(2131427423);
        this.n = (Button)this.findViewById(2131427424);
        this.fz = (Button)this.findViewById(2131427421);
        this.f = (Button)this.findViewById(2131427419);
        this.vf = (Button)this.findViewById(2131427415);
        AdRequest.Builder builder = new AdRequest.Builder();
        AdRequest adRequest = builder.build();
        this.mAdView.loadAd(adRequest);
        Button button = this.s;
        100000000 var5_5 = new 100000000(this);
        button.setOnClickListener((View.OnClickListener)var5_5);
        Button button2 = this.v;
        100000001 var7_7 = new 100000001(this);
        button2.setOnClickListener((View.OnClickListener)var7_7);
        Button button3 = this.vc;
        100000002 var9_9 = new 100000002(this);
        button3.setOnClickListener((View.OnClickListener)var9_9);
        Button button4 = this.n;
        100000003 var11_11 = new 100000003(this);
        button4.setOnClickListener((View.OnClickListener)var11_11);
        Button button5 = this.fz;
        100000004 var13_13 = new 100000004(this);
        button5.setOnClickListener((View.OnClickListener)var13_13);
        Button button6 = this.f;
        100000005 var15_15 = new 100000005(this);
        button6.setOnClickListener((View.OnClickListener)var15_15);
        Button button7 = this.vf;
        100000006 var17_17 = new 100000006(this);
        button7.setOnClickListener((View.OnClickListener)var17_17);
    }

    @Override
    public void onDestroy() {
        if (this.mAdView != null) {
            this.mAdView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onPause() {
        if (this.mAdView != null) {
            this.mAdView.pause();
        }
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (this.mAdView != null) {
            this.mAdView.resume();
        }
    }

    class 100000000
    implements View.OnClickListener {
        private final furacao this$0;

        100000000(furacao furacao2) {
            this.this$0 = furacao2;
        }

        static furacao access$0(100000000 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            this.this$0.finish();
        }
    }

    class 100000001
    implements View.OnClickListener {
        private final furacao this$0;

        100000001(furacao furacao2) {
            this.this$0 = furacao2;
        }

        static furacao access$0(100000001 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            Class class_;
            furacao furacao2 = this.this$0;
            try {
                class_ = Class.forName((String)"com.mycompany.Ccampos.MainActivity");
            }
            catch (ClassNotFoundException classNotFoundException) {
                NoClassDefFoundError noClassDefFoundError = new NoClassDefFoundError(classNotFoundException.getMessage());
                throw noClassDefFoundError;
            }
            Intent intent = new Intent((Context)furacao2, class_);
            this.this$0.startActivity(intent);
            this.this$0.finish();
        }
    }

    class 100000002
    implements View.OnClickListener {
        private Intent intent;
        private final furacao this$0;

        100000002(furacao furacao2) {
            this.this$0 = furacao2;
        }

        static furacao access$0(100000002 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            Class class_;
            furacao furacao2 = this.this$0;
            try {
                class_ = Class.forName((String)"com.mycompany.Ccampos.fvc");
            }
            catch (ClassNotFoundException classNotFoundException) {
                NoClassDefFoundError noClassDefFoundError = new NoClassDefFoundError(classNotFoundException.getMessage());
                throw noClassDefFoundError;
            }
            Intent intent = new Intent((Context)furacao2, class_);
            this.this$0.startActivity(intent);
            this.this$0.finish();
        }
    }

    class 100000003
    implements View.OnClickListener {
        private final furacao this$0;

        100000003(furacao furacao2) {
            this.this$0 = furacao2;
        }

        static furacao access$0(100000003 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            Class class_;
            furacao furacao2 = this.this$0;
            try {
                class_ = Class.forName((String)"com.mycompany.Ccampos.frm");
            }
            catch (ClassNotFoundException classNotFoundException) {
                NoClassDefFoundError noClassDefFoundError = new NoClassDefFoundError(classNotFoundException.getMessage());
                throw noClassDefFoundError;
            }
            Intent intent = new Intent((Context)furacao2, class_);
            this.this$0.startActivity(intent);
            this.this$0.finish();
        }
    }

    class 100000004
    implements View.OnClickListener {
        private final furacao this$0;

        100000004(furacao furacao2) {
            this.this$0 = furacao2;
        }

        static furacao access$0(100000004 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            Class class_;
            furacao furacao2 = this.this$0;
            try {
                class_ = Class.forName((String)"com.mycompany.Ccampos.faf");
            }
            catch (ClassNotFoundException classNotFoundException) {
                NoClassDefFoundError noClassDefFoundError = new NoClassDefFoundError(classNotFoundException.getMessage());
                throw noClassDefFoundError;
            }
            Intent intent = new Intent((Context)furacao2, class_);
            this.this$0.startActivity(intent);
            this.this$0.finish();
        }
    }

    class 100000005
    implements View.OnClickListener {
        private final furacao this$0;

        100000005(furacao furacao2) {
            this.this$0 = furacao2;
        }

        static furacao access$0(100000005 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            Class class_;
            furacao furacao2 = this.this$0;
            try {
                class_ = Class.forName((String)"com.mycompany.Ccampos.avancovolta2");
            }
            catch (ClassNotFoundException classNotFoundException) {
                NoClassDefFoundError noClassDefFoundError = new NoClassDefFoundError(classNotFoundException.getMessage());
                throw noClassDefFoundError;
            }
            Intent intent = new Intent((Context)furacao2, class_);
            this.this$0.startActivity(intent);
            this.this$0.finish();
        }
    }

    class 100000006
    implements View.OnClickListener {
        private final furacao this$0;

        100000006(furacao furacao2) {
            this.this$0 = furacao2;
        }

        static furacao access$0(100000006 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            Class class_;
            furacao furacao2 = this.this$0;
            try {
                class_ = Class.forName((String)"com.mycompany.Ccampos.fam");
            }
            catch (ClassNotFoundException classNotFoundException) {
                NoClassDefFoundError noClassDefFoundError = new NoClassDefFoundError(classNotFoundException.getMessage());
                throw noClassDefFoundError;
            }
            Intent intent = new Intent((Context)furacao2, class_);
            this.this$0.startActivity(intent);
            this.this$0.finish();
        }
    }

}

