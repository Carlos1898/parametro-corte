/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  com.google.android.gms.ads.AdRequest
 *  com.google.android.gms.ads.AdRequest$Builder
 *  com.google.android.gms.ads.AdView
 *  com.google.android.gms.ads.MobileAds
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.NoClassDefFoundError
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package com.mycompany.Ccampos;

import adrt.ADRTLogCatReader;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

public class tc
extends Activity {
    private AdView mAdView;
    Button s;
    Button v;

    @Override
    public void onCreate(Bundle bundle) {
        ADRTLogCatReader.onContext((Context)this, "com.aide.ui");
        super.onCreate(bundle);
        this.setContentView(2130903090);
        MobileAds.initialize((Context)this, (String)"ca-app-pub-3940256099942544/6300978111");
        this.mAdView = (AdView)this.findViewById(2131427410);
        this.s = (Button)this.findViewById(2131427416);
        this.v = (Button)this.findViewById(2131427417);
        AdRequest.Builder builder = new AdRequest.Builder();
        AdRequest adRequest = builder.build();
        this.mAdView.loadAd(adRequest);
        Button button = this.s;
        100000000 var5_5 = new 100000000(this);
        button.setOnClickListener((View.OnClickListener)var5_5);
        Button button2 = this.v;
        100000001 var7_7 = new 100000001(this);
        button2.setOnClickListener((View.OnClickListener)var7_7);
    }

    @Override
    public void onDestroy() {
        if (this.mAdView != null) {
            this.mAdView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onPause() {
        if (this.mAdView != null) {
            this.mAdView.pause();
        }
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (this.mAdView != null) {
            this.mAdView.resume();
        }
    }

    class 100000000
    implements View.OnClickListener {
        private final tc this$0;

        100000000(tc tc2) {
            this.this$0 = tc2;
        }

        static tc access$0(100000000 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            this.this$0.finish();
        }
    }

    class 100000001
    implements View.OnClickListener {
        private final tc this$0;

        100000001(tc tc2) {
            this.this$0 = tc2;
        }

        static tc access$0(100000001 var0) {
            return var0.this$0;
        }

        @Override
        public void onClick(View view) {
            Class class_;
            tc tc2 = this.this$0;
            try {
                class_ = Class.forName((String)"com.mycompany.Ccampos.MainActivity");
            }
            catch (ClassNotFoundException classNotFoundException) {
                NoClassDefFoundError noClassDefFoundError = new NoClassDefFoundError(classNotFoundException.getMessage());
                throw noClassDefFoundError;
            }
            Intent intent = new Intent((Context)tc2, class_);
            this.this$0.startActivity(intent);
            this.this$0.finish();
        }
    }

}

