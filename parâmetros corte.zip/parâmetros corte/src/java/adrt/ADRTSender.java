/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package adrt;

import android.content.Context;
import android.content.Intent;
import java.io.Serializable;
import java.util.ArrayList;

public class ADRTSender {
    private static Context context;
    private static String debuggerPackageName;

    public static void onContext(Context context, String string2) {
        ADRTSender.context = context;
        debuggerPackageName = string2;
    }

    public static void sendBreakpointHit(String string2, ArrayList<String> arrayList, ArrayList<String> arrayList2, ArrayList<String> arrayList3, ArrayList<String> arrayList4, ArrayList<String> arrayList5, ArrayList<String> arrayList6) {
        Intent intent = new Intent();
        intent.setPackage(debuggerPackageName);
        intent.setAction("com.adrt.BREAKPOINT_HIT");
        intent.putExtra("package", string2);
        intent.putExtra("variables", arrayList);
        intent.putExtra("variableValues", arrayList2);
        intent.putExtra("variableKinds", arrayList3);
        intent.putExtra("stackMethods", arrayList4);
        intent.putExtra("stackLocations", arrayList5);
        intent.putExtra("stackLocationKinds", arrayList6);
        context.sendBroadcast(intent);
    }

    public static void sendConnect(String string2) {
        Intent intent = new Intent();
        intent.setPackage(debuggerPackageName);
        intent.setAction("com.adrt.CONNECT");
        intent.putExtra("package", string2);
        context.sendBroadcast(intent);
    }

    public static void sendFields(String string2, String string3, ArrayList<String> arrayList, ArrayList<String> arrayList2, ArrayList<String> arrayList3) {
        Intent intent = new Intent();
        intent.setPackage(debuggerPackageName);
        intent.setAction("com.adrt.FIELDS");
        intent.putExtra("package", string2);
        intent.putExtra("path", string3);
        intent.putExtra("fields", arrayList);
        intent.putExtra("fieldValues", arrayList2);
        intent.putExtra("fieldKinds", arrayList3);
        context.sendBroadcast(intent);
    }

    public static void sendLogcatLines(String[] arrstring) {
        Intent intent = new Intent();
        intent.setPackage(debuggerPackageName);
        intent.setAction("com.adrt.LOGCAT_ENTRIES");
        intent.putExtra("lines", arrstring);
        context.sendBroadcast(intent);
    }

    public static void sendStop(String string2) {
        Intent intent = new Intent();
        intent.setPackage(debuggerPackageName);
        intent.setAction("com.adrt.STOP");
        intent.putExtra("package", string2);
        context.sendBroadcast(intent);
    }
}

