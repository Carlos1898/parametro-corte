/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  java.io.BufferedReader
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.Reader
 *  java.lang.Object
 *  java.lang.Process
 *  java.lang.Runnable
 *  java.lang.Runtime
 *  java.lang.String
 *  java.lang.Thread
 */
package adrt;

import adrt.ADRTSender;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class ADRTLogCatReader
implements Runnable {
    private static Context context;

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static void onContext(Context context, String string2) {
        if (ADRTLogCatReader.context != null) {
            return;
        }
        ADRTLogCatReader.context = context.getApplicationContext();
        if ((2 & context.getApplicationInfo().flags) == 0) return;
        boolean bl = true;
        if (!bl) {
            return;
        }
        try {
            context.getPackageManager().getPackageInfo(string2, 128);
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            return;
        }
        ADRTSender.onContext(ADRTLogCatReader.context, string2);
        ADRTLogCatReader aDRTLogCatReader = new ADRTLogCatReader();
        Thread thread = new Thread((Runnable)aDRTLogCatReader, "LogCat");
        thread.start();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void run() {
        try {
            Process process = Runtime.getRuntime().exec("logcat -v threadtime");
            InputStreamReader inputStreamReader = new InputStreamReader(process.getInputStream());
            BufferedReader bufferedReader = new BufferedReader((Reader)inputStreamReader, 20);
            do {
                String string2;
                if ((string2 = bufferedReader.readLine()) == null) {
                    return;
                }
                ADRTSender.sendLogcatLines(new String[]{string2});
            } while (true);
        }
        catch (IOException iOException) {
            return;
        }
    }
}

